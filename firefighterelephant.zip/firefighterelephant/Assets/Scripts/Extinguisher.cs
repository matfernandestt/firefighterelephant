﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Extinguisher : MonoBehaviour
{
	public FireType ExtinguisherType;
}
