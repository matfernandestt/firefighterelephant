﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Stair : MonoBehaviour
{
	public Stair UpStair;
	public Stair DownStair;
	public Transform Room;
}
